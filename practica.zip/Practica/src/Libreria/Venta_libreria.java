package Libreria;

public class Venta_libreria {

	public class Venta_de_libro {
		
	}
	public String nombre_del_solicitantes;
	public int fecha_del_prestamo;
	public String titulo_del_libro;
	public String editorial;
	public String autorDelLibro;
	public  String tipo_de_libro;
	
	
	public Venta_libreria(String nombre_del_solicitantes, String autorDelLibro, String titulo_del_libro,
			String editorial, int fecha_del_prestamo, String tipo_de_libro) {
		super();
		this.nombre_del_solicitantes = nombre_del_solicitantes;
		this.fecha_del_prestamo = fecha_del_prestamo;
		this.titulo_del_libro = titulo_del_libro;
		this.editorial = editorial;
		this.autorDelLibro = autorDelLibro;
		this.tipo_de_libro = tipo_de_libro;
	}


	public String getNombre_del_solicitantes() {
		return nombre_del_solicitantes;
	}


	public void setNombre_del_solicitantes(String nombre_del_solicitantes) {
		this.nombre_del_solicitantes = nombre_del_solicitantes;
	}


	public String getTitulo_del_libro() {
		return titulo_del_libro;
	}


	public void setTitulo_del_libro(String titulo_del_libro) {
		this.titulo_del_libro = titulo_del_libro;
	}


	public String getEditorial() {
		return editorial;
	}


	public void setEditorial(String editorial) {
		this.editorial = editorial;
	}


	public String getAutorDelLibro() {
		return autorDelLibro;
	}


	public void setAutorDelLibro(String autorDelLibro) {
		this.autorDelLibro = autorDelLibro;
	}


	public String getTipo_de_libro() {
		return tipo_de_libro;
	}


	public void setTipo_de_libro(String tipo_de_libro) {
		this.tipo_de_libro = tipo_de_libro;
	}
	
	public void Mostrar() {
		System.out.println(" ");
	}
	
	
	
	
}
