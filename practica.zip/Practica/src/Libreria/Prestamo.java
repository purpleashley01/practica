package Libreria;

public class Prestamo {

	
	int expi_prestamo;
	int multa;
	int carnet;
	int fecha_del_prestamo;
	String name;
	
	public Prestamo(int expi_prestamo, int multa, int carnet,int fecha_del_prestamo,String name) {
		super();
		this.expi_prestamo = expi_prestamo;
		this.multa = multa;
		this.carnet = carnet;
		this.fecha_del_prestamo=fecha_del_prestamo;
		this.name = name;
	}
	public int getExpi_prestamo() {
		return expi_prestamo;
	}
	public void setExpi_prestamo(int expi_prestamo) {
		this.expi_prestamo = expi_prestamo;
	}
	public int getMulta() {
		return multa;
	}
	public void setMulta(int multa) {
		this.multa = multa;
	}
	public int getCarnet() {
		return carnet;
	}
	public void setCarnet(int carnet) {
		this.carnet = carnet;
	}
	public int getFecha_del_prestamo() {
		return fecha_del_prestamo;
	}
	public void setFecha_del_prestamo(int fecha_del_prestamo) {
		this.fecha_del_prestamo = fecha_del_prestamo;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
