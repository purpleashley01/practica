package Libreria;
import java.util.Scanner;
public class Biblioteca {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner teclado=new Scanner (System.in);
		
		
		int op=0;
		String libro,autor,edit;
		String name_user;
		int cant;
		String titulo;
		
		
		System.out.println("***************************");
		System.out.println("¡¡Menú de opciones!!");
		System.out.println("Eliga del 1 al 10 en el menú de opciones:");
		op=teclado.nextInt();
		
		switch (op) {
		
		case 1: 
			System.out.println("Ingrese su nombre:");
		name_user=teclado.nextLine();
		teclado.nextLine();
		case 2: 
			System.out.println("¿Cuántos libros desea registrar/prestar?");
			cant=teclado.nextInt();
			teclado.nextLine();
		case 3:
			System.out.println("Ingrese el titulo del libro:");
			titulo=teclado.nextLine();
		case 4:
			System.out.println("Ingrese el autor:");
			autor=teclado.next();
		case 5:
			System.out.println("Ingrese la editorial:");
			edit=teclado.next();
		}
		
     Venta_de_libros bibli= new Venta_de_libros();
     Venta_de_libros nombre_del_solicitantes= new Venta_de_libros();
	
		
		
		
		
	
		
		
	}

}
